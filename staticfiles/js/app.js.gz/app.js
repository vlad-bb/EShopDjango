var message_timeout_success = document.getElementById("message-timer-success");
setTimeout(function()
{
    message_timeout_success.style.display = "none";
}, 2500);

var message_timeout_error = document.getElementById("message-timer-error");
setTimeout(function()
{
    message_timeout_error.style.display = "none";
}, 2500);

var message_timeout_info = document.getElementById("message-timer-info");
setTimeout(function()
{
    message_timeout_info.style.display = "none";
}, 2500);